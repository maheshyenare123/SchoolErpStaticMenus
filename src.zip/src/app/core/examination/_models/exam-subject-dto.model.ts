import { ExamSubjectModel } from './exam-subject.model';

export class ExamSubjectDtoModel {
   

   
}