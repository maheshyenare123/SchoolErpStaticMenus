import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-error5',
  templateUrl: './error5.component.html',
  styleUrls: ['./../../../../../assets/sass/pages/error/error-5.scss']
})
export class Error5Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
