import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-source',
  templateUrl: './source.component.html',
  styleUrls: ['./source.component.scss']
})
export class SourceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
