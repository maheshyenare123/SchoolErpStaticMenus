import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-reference',
  templateUrl: './reference.component.html',
  styleUrls: ['./reference.component.scss']
})
export class ReferenceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
