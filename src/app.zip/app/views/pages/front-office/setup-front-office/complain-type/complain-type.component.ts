import { Component, OnInit, ChangeDetectionStrategy, ElementRef, ViewChild, Input } from '@angular/core';
import { Observable, Subscription, merge, fromEvent, of } from 'rxjs';
import { ComplainTypesDataSource, ComplaintTypeModel, ComplaintTypesPageRequested, ComplaintTypeUpdated, OneComplaintTypeDeleted, ManyComplaintTypesDeleted, ComplaintTypeStoreUpdated, ComplaintTypeOnServerCreated, selectLastCreatedComplaintTypeId } from '../../../../../core/front-office';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { SelectionModel } from '@angular/cdk/collections';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Store, select } from '@ngrx/store';
import { AppState } from '../../../../../core/reducers';
import { MatDialog } from '@angular/material/dialog';
import { TypesUtilsService, LayoutUtilsService, QueryParamsModel, MessageType } from '../../../../../core/_base/crud';
import { tap, debounceTime, distinctUntilChanged, delay } from 'rxjs/operators';
import { Update } from '@ngrx/entity';

@Component({
  selector: 'kt-complain-type',
  templateUrl: './complain-type.component.html',
  styleUrls: ['./complain-type.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ComplainTypeComponent implements OnInit {
  
// Public properties
	// Incoming data
	@Input() complainTypeId$: Observable<number>;
	complainTypeId: number;
	// Table fields
	dataSource: ComplainTypesDataSource;
	displayedColumns = ['id', 'complainType', 'actions'];
	@ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
	@ViewChild(MatSort, {static: true}) sort: MatSort;
	// Filter fields
	@ViewChild('searchInput', {static: true}) searchInput: ElementRef;
	// Selection
	selection = new SelectionModel<ComplaintTypeModel>(true, []);
	complaintTypesResult: ComplaintTypeModel[] = [];
	// Add and Edit
	isSwitchedToEditMode = false;
	loadingAfterSubmit = false;
	complainTypeForm: FormGroup;
	complainTypeForEdit: ComplaintTypeModel;
	complainTypeForAdd: ComplaintTypeModel;
	// Private properties
	private componentSubscriptions: Subscription;

	/**
	 * Component constructor
	 *
	 * @param store: Store<AppState>
	 * @param fb: FormBuilder
	 * @param dialog: MatDialog
	 * @param typesUtilsService: TypeUtilsService
	 * @param layoutUtilsService: LayoutUtilsService
	 */
	constructor(private store: Store<AppState>,
		           private fb: FormBuilder,
		           public dialog: MatDialog,
		           public typesUtilsService: TypesUtilsService,
		           private layoutUtilsService: LayoutUtilsService) {}

	/**
	 * @ Lifecycle sequences => https://angular.io/guide/lifecycle-hooks
	 */

	/**
	 * On init
	 */
	ngOnInit() {
		// If the user changes the sort order, reset back to the first page.
		this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));
		/* Data load will be triggered in two cases:
		- when a pagination event occurs => this.paginator.page
		- when a sort event occurs => this.sort.sortChange
		**/
		merge(this.sort.sortChange, this.paginator.page)
			.pipe(
				tap(() => {
					this.loadComplaintTypesList();
				})
			)
			.subscribe();

		// Filtration, bind to searchInput
		fromEvent(this.searchInput.nativeElement, 'keyup')
			.pipe(
				debounceTime(150),
				distinctUntilChanged(),
				tap(() => {
					this.paginator.pageIndex = 0;
					this.loadComplaintTypesList();
				})
			)
			.subscribe();

		// Init DataSource
		this.dataSource = new ComplainTypesDataSource(this.store);
		this.dataSource.entitySubject.subscribe(res => this.complaintTypesResult = res);
		// this.complainTypeId$.subscribe(res => {
		// 	if (!res) {
		// 		return;
		// 	}

		// 	this.complainTypeId = res;
			of(undefined).pipe(delay(1000)).subscribe(() => { // Remove this line, just loading imitation
				this.loadComplaintTypesList();
			}); // Remove this line, just loading imitation
			this.createFormGroup();
		// });
	}

	/**
	 * On destroy
	 */
	ngOnDestroy() {
		if (this.componentSubscriptions) {
			this.componentSubscriptions.unsubscribe();
		}
	}

	/**
	 * Loading Remarks list
	 */
	loadComplaintTypesList() {
		this.selection.clear();
		const queryParams = new QueryParamsModel(
			this.filterConfiguration(),
			this.sort.direction,
			this.sort.active,
			this.paginator.pageIndex,
			this.paginator.pageSize
		);
		// Call request from server
		this.store.dispatch(new ComplaintTypesPageRequested({
			page: queryParams
		}));
	}

	/**
	 * Create Reactive Form
	 * @param _item: remark
	 */
	createFormGroup(_item = null) {
		// 'edit' prefix - for item editing
		// 'add' prefix - for item creation
		this.complainTypeForm = this.fb.group({
			editComplainType: ['', Validators.compose([Validators.required])],
		newComplainType: ['', Validators.compose([Validators.required])],
			});
		this.clearAddForm();
		this.clearEditForm();
	}

	// ADD REMARK FUNCTIONS: clearAddForm | checkAddForm | addRemarkButtonOnClick | cancelAddButtonOnClick | saveNewRemark
	clearAddForm() {
		const controls = this.complainTypeForm.controls;
		controls.newComplainType.setValue('');
		controls.newComplainType.markAsPristine();
		controls.newComplainType.markAsUntouched();
	

		this.complainTypeForAdd = new ComplaintTypeModel();
		this.complainTypeForAdd.clear(this.complainTypeId);
		// this.complainTypeForAdd.dueDate = this.typesUtilsService.getDateStringFromDate();
		this.complainTypeForAdd._isEditMode = false;
	}

	/**
	 * Check if Add Form is Valid
	 */
	checkAddForm() {
		const controls = this.complainTypeForm.controls;
		if (controls.newComplainType.invalid ) {
			controls.newComplainType.markAsTouched();
			controls.newComplainType.markAsTouched();
			return false;
		}

		return true;
	}

	/**
	 * Open Remark Add Form
	 */
	addComplaintTypeButtonOnClick() {
		this.clearAddForm();
		this.complainTypeForAdd._isEditMode = true;
		this.isSwitchedToEditMode = true;
	}

	/**
	 * Close Remark Add Form
	 */
	cancelAddButtonOnClick() {
		this.complainTypeForAdd._isEditMode = false;
		this.isSwitchedToEditMode = false;
	}

	/**
	 *  Create new remark
	 */
	saveNewRemark() {
		if (!this.checkAddForm()) {
			return;
		}

		const controls = this.complainTypeForm.controls;
		this.loadingAfterSubmit = false;
		this.complainTypeForAdd._isEditMode = false;
		// this.complainTypeForAdd.text = controls.newComplainType.value;
		// this.complainTypeForAdd.type = +controls.newType.value;
		// const _date = new Date(controls.newDueDate.value);
		// this.complainTypeForAdd.dueDate = this.typesUtilsService.getDateStringFromDate(_date);
		// this.complainTypeForAdd._updatedDate = this.typesUtilsService.getDateStringFromDate();
		// this.complainTypeForAdd._createdDate = this.complainTypeForEdit._updatedDate;
		// this.complainTypeForAdd._userId = 1; // Admin TODO: Get from user servics
		this.store.dispatch(new ComplaintTypeOnServerCreated({ complaintType: this.complainTypeForAdd }));
		this.componentSubscriptions = this.store.pipe(
				select(selectLastCreatedComplaintTypeId)
			).subscribe(res => {
				if (!res) {
					return;
				}

				const _saveMessage = `Remark has been created`;
				this.isSwitchedToEditMode = false;
				this.layoutUtilsService.showActionNotification(_saveMessage, MessageType.Create, 10000, true, true);
				this.clearAddForm();
			});
	}

	// EDIT REMARK FUNCTIONS: clearEditForm | checkEditForm | editRemarkButtonOnClick | cancelEditButtonOnClick |
	clearEditForm() {
		const controls = this.complainTypeForm.controls;
		controls.editComplainType.setValue('');
		controls['editComplainType'].markAsPristine();
		controls['editComplainType'].markAsUntouched();
		// controls.editType.setValue('0');
		// controls['editType'].markAsPristine();
		// controls['editType'].markAsUntouched();
		// controls.editDueDate.setValue(this.typesUtilsService.getDateFromString());
		// controls['editDueDate'].markAsPristine();
		// controls['editDueDate'].markAsUntouched();

		this.complainTypeForEdit = new ComplaintTypeModel();
		this.complainTypeForEdit.clear(this.complainTypeId);
		// this.complainTypeForEdit.dueDate = this.typesUtilsService.getDateStringFromDate();
		this.complainTypeForEdit._isEditMode = false;
	}

	/**
	 * Check is Edit Form valid
	 */
	checkEditForm() {
		const controls = this.complainTypeForm.controls;
		if (controls.editComplainType.invalid ) {
			// controls['editComplainType'].markAsTouched();
			// controls['editType'].markAsTouched();
			// controls['editDueDate'].markAsTouched();
			return false;
		}

		return true;
	}

	/**
	 * Update remark
	 *
	 * @param _item: ComplaintTypeModel
	 */
	editRemarkButtonOnClick(_item: ComplaintTypeModel) {
		const controls = this.complainTypeForm.controls;
		controls.editComplainType.setValue(_item.complaintType);
		controls.editType.setValue(_item.type.toString());
		// controls.editDueDate.setValue(this.typesUtilsService.getDateFromString(_item.dueDate));
		const updateProductReamrk: Update<ComplaintTypeModel> = {
			id: _item.id,
			changes: {
				_isEditMode: true
			}
		};
		this.store.dispatch(new ComplaintTypeStoreUpdated({ complainType: updateProductReamrk }));
		this.isSwitchedToEditMode = true;
	}

	/**
	 * Cancel remark
	 *
	 * @param _item: ComplaintTypeModel
	 */
	cancelEditButtonOnClick(_item: ComplaintTypeModel) {
		const updateProductReamrk: Update<ComplaintTypeModel> = {
			id: _item.id,
			changes: {
				_isEditMode: false
			}
		};
		this.store.dispatch(new ComplaintTypeStoreUpdated({ complainType: updateProductReamrk }));
		this.isSwitchedToEditMode = false;
	}

	/**
	 * Save remark
	 *
	 * @param _item: ComplaintTypeModel
	 */
	saveUpdatedRemark(_item: ComplaintTypeModel) {
		if (!this.checkEditForm()) {
			return;
		}

		this.loadingAfterSubmit = true;
		const controls = this.complainTypeForm.controls;
		this.loadingAfterSubmit = false;
		const objectForUpdate = new ComplaintTypeModel();
		objectForUpdate.id = _item.id;
		// objectForUpdate.carId = _item.carId;
		// objectForUpdate._isEditMode = _item._isEditMode;
		// objectForUpdate.text = controls.editComplainType.value;
		// objectForUpdate.type = +controls.editType.value;
		// const _date = new Date(controls.editDueDate.value);
		// objectForUpdate.dueDate = this.typesUtilsService.getDateStringFromDate(_date);
    // objectForUpdate._updatedDate = this.typesUtilsService.getDateStringFromDate();
    
		objectForUpdate._isEditMode = false;
		const updateProductReamrk: Update<ComplaintTypeModel> = {
			id: _item.id,
			changes: objectForUpdate
		};

		this.store.dispatch(new ComplaintTypeUpdated({
			partialComplaintType: updateProductReamrk,
			complaintType: objectForUpdate
		}));
		const saveMessage = `Complaint Type has been updated`;
		this.isSwitchedToEditMode = false;
		this.layoutUtilsService.showActionNotification(saveMessage, MessageType.Update, 10000, true, true);
	}

	/**
	 * Returns object for filtration
	 */
	filterConfiguration(): any {
		const filter: any = {};
		const searchText: string = this.searchInput.nativeElement.value;

		filter.text = searchText;
		return filter;
	}

	/**
	 * Check all rows are selected
	 */
	isAllSelected() {
		const numSelected = this.selection.selected.length;
		const numRows = this.complaintTypesResult.length;
		return numSelected === numRows;
	}

	/**
	 * Selects all rows if they are not all selected; otherwise clear selection
	 */
	masterToggle() {
		if (this.isAllSelected()) {
			this.selection.clear();
		} else {
			this.complaintTypesResult.forEach(row => this.selection.select(row));
		}
	}

	/** ACTIONS */
	/**
	 * Delete remark
	 *
	 * @param _item: ComplaintTypeModel
	 */
	deleteRemark(_item: ComplaintTypeModel) {
		const _title = 'Remark Delete';
		const _description = 'Are you sure to permanently delete this remark?';
		const _waitDesciption = 'Remark is deleting...';
		const _deleteMessage = `Remark has been deleted`;

		const dialogRef = this.layoutUtilsService.deleteElement(_title, _description, _waitDesciption);
		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}

			this.store.dispatch(new OneComplaintTypeDeleted({ id: _item.id }));
			this.layoutUtilsService.showActionNotification(_deleteMessage, MessageType.Delete);
		});
	}

	/**
	 * Delete selected remarks
	 */
	deleteRemarks() {
		const _title = 'Remarks Delete';
		const _description = 'Are you sure to permanently delete selected remarks?';
		const _waitDesciption = 'Remarks are deleting...';
		const _deleteMessage = 'Selected remarks have been deleted';

		const dialogRef = this.layoutUtilsService.deleteElement(_title, _description, _waitDesciption);
		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}

			const length = this.selection.selected.length;
			const idsForDeletion: number[] = [];
			for (let i = 0; i < length; i++) {
				idsForDeletion.push(this.selection.selected[i].id);
			}
			this.store.dispatch(new ManyComplaintTypesDeleted({ ids: idsForDeletion }));
			this.layoutUtilsService.showActionNotification(_deleteMessage, MessageType.Delete);
			this.selection.clear();
		});
	}

	/**
	 * Fetch selected remarks
	 */
	fetchRemarks() {
		const messages = [];
		this.selection.selected.forEach(elem => { messages.push({ text: `${elem.complaintType}`, id: elem.id }); });
		this.layoutUtilsService.fetchElements(messages);
	}

	/* UI **/
	/**
	 * Returns type in string
	 *
	 * @param _remark: ComplaintTypeModel
	 */
	getTypeStr(_remark: ComplaintTypeModel): string {
		switch (_remark.type) {
			case 0: return 'Info';
			case 1: return 'Note';
			case 2: return 'Reminder';
			default: return '';
		}
	}
}
