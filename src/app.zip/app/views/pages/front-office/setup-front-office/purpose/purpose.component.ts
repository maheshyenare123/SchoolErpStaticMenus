import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-purpose',
  templateUrl: './purpose.component.html',
  styleUrls: ['./purpose.component.scss']
})
export class PurposeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
