export class Constants {
    public static URL: any = {
        HOST_URL: 'http://yamistha.cloudjiffy.net/',
       accessToken:'',
       sessionId:'1',

    }

    public static Front_Office: any = {
       Admission_Enquiry:'api/enquiry',
       Complain:'',
       ComplainType:'',
       Phone_Call_Log:'',
       Postal_Dispatch:'',
       Postal_Receive:'',
       Visitor_Book:'',
       Purpose:'',
       Reference:'',
       Source:'',
    }


    
}