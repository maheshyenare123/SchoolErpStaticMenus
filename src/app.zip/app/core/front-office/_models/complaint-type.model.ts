import { TimestampModel } from "./timestamp.model";
export class ComplaintTypeModel {

    complaintType: string;
    createdAt:TimestampModel;
    description: string;
    id: number;
    isActive: string;


    type: number; // Info, Note, Reminder
  
  // tslint:disable-next-line
  _isEditMode: boolean;
    // clear() {
    //     this.id = 0;
    //     this.complaintType = '';;
    //     this.createdAt=new TimestampModel;
    //     this.description = '';
    //     this.isActive = '';
    // }
    clear(carId: number) {
      this.id = 0;
      this.complaintType = '';;
      this.createdAt=new TimestampModel;
      this.description = '';
      this.isActive = '';
      this._isEditMode = false;
    }
}