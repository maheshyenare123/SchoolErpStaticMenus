export { AuthService } from './auth.service.fake'; // You have to comment this, when your real back-end is done
// export { AuthService } from './auth.service'; // You have to uncomment this, when your real back-end is done
