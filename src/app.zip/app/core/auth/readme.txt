Our Auth module based on NGRX
More details => https://mherman.org/blog/authentication-in-angular-with-ngrx/